import math
import os
import os.path
import pickle

import face_recognition
import numpy as np
from PIL import Image, ImageDraw
from PIL import ImageFont
from face_recognition.face_recognition_cli import image_files_in_folder
from sklearn import neighbors
import cv2
from cv2 import face


ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
font = ImageFont.truetype('./static/simsun.ttc')

label2name = {}

recognizer = cv2.face.LBPHFaceRecognizer_create()


def train(train_dir):
    X = []
    y = []

    for class_dir in os.listdir(train_dir):
        if not os.path.isdir(os.path.join(train_dir, class_dir)):
            continue
        path = os.path.join(train_dir, class_dir)
        for img_path in os.listdir(path):
            PIL_img = Image.open(os.path.join(path, img_path)).convert('L')  # convert it to grayscale
            img_numpy = np.array(PIL_img, 'uint8')

            X.append(img_numpy)
            y.append(int(class_dir))


    clf = recognizer.train(X, np.array(y))
    recognizer.write('trainer.yml')

    return clf


if __name__ == "__main__":

    print("Training KNN classifier...")
    classifier = train("static/datasets")
    print("Training complete!")

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    img = cv2.imread('1.jpeg')
    recognizer.read('trainer.yml')

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    faces = face_recognition.face_locations(img)

    for (top, right, bottom, left) in faces:
        cv2.rectangle(img, (left, top), (right, bottom), (0, 255, 0), 2)

        id, confidence = recognizer.predict(gray[top:bottom, left:right])
        print(id, confidence)

