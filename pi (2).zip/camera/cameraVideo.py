import datetime
import json
import time

import PIL
import cv2
import face_recognition
import numpy as np
from PIL import ImageFont
from PIL import ImageDraw


class VideoCamera(object):
    def __init__(self):
        # 通过opencv获取实时视频流
        self.video = cv2.VideoCapture(0)
        self.face_detector = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        self.recognizer = cv2.face.LBPHFaceRecognizer_create()
        self.recognizer.read('trainer.yml')
        self.name = {}
        self.font_1 = ImageFont.truetype('../static/simsun.ttc', 30)  # 加载字体, 字体大小

        with open('label.txt', 'r', encoding='utf-8') as f:
            load_dict = json.load(f)
        for k, v in load_dict.items():
            self.name[v] = k

        self.f = open('output.txt', 'a', encoding='utf-8')

    def __del__(self):
        self.video.release()
        self.f.close()

    def get_Recognizer_frame(self):
        success, image = self.video.read()
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        faces = face_recognition.face_locations(image)

        for (top, right, bottom, left) in faces:
            cv2.rectangle(image, (left, top), (right, bottom), (0, 255, 255), 2)
            self.gray = gray[top:bottom, left:right]
            id, confidence = self.recognizer.predict(self.gray)
            if confidence < 100:
                name = self.name[str(id)]
                confidence = "  {0}%".format(round(100 - confidence))
            else:
                name = "unknown"
                confidence = "  {0}%".format(round(100 - confidence))
            self.f.write(datetime.datetime.now().strftime("%Y-%m-%d, %H:%M:%S") + '\t' + name + '\n')
            print(datetime.datetime.now().strftime("%Y-%m-%d, %H:%M:%S") + '\t' + name + '\n')
            img_pil = PIL.Image.fromarray(image)
            draw = ImageDraw.Draw(img_pil)
            draw.text((left + 10, bottom - 32), name, font=self.font_1, fill=(0, 255, 0))
            image = np.array(img_pil)

        ret, jpeg = cv2.imencode('.jpg', image)
        return jpeg.tobytes(), image

    def get_face_frame(self):
        success, image = self.video.read()
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        faces = face_recognition.face_locations(image)

        for (top, right, bottom, left) in faces:
            cv2.rectangle(image, (left, top), (right, bottom), (0, 255, 255), 2)
            gray = gray[top:bottom, left:right]
            break

        # 因为opencv读取的图片并非jpeg格式，因此要用motion JPEG模式需要先将图片转码成jpg格式图片
        ret, jpeg = cv2.imencode('.jpg', image)
        return jpeg.tobytes(), gray


def gen(camera):
    while True:
        frame, _ = camera.get_face_frame()
        # 使用generator函数输出视频流， 每次请求输出的content类型是image/jpeg
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')


def gen2(camera):
    while True:
        frame, _ = camera.get_Recognizer_frame()
        # 使用generator函数输出视频流， 每次请求输出的content类型是image/jpeg
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')
